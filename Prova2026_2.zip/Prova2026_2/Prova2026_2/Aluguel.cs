﻿public class Aluguel:Veiculo
{
    public Veiculo veiculo;
    public DateTime dataInicio;
    public DateTime dataFim;
    public int totalDay;
    public double valorTotal;


    public double CalcularTotalAluguel()
    {
        valorTotal = veiculo.CalcularAluguel(totalDay);
        return valorTotal;
    }
    public Aluguel(Veiculo veiculo, DateTime dataInicio, DateTime dataFim)
    {
        this.veiculo = veiculo;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;

        totalDay = (dataFim - dataInicio).Days;

        if(dataInicio >= dataFim)
        {
            throw new Exception("A data de fim deve ser porterior a data de inicio, revise as datas");
        }
    }
}