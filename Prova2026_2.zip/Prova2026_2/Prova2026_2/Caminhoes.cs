﻿public class Caminhoes:Veiculo
{
    public int eixos;
    public double carga;
    public string carroceria;
    public double comprimento;
    public double altura;
    public override double CalcularAluguel(int carg)
    {
        carga = carg;

        if (carg > 10000)
        {
            return base.CalcularAluguel(carg)*0.2;
        }
        return base.CalcularAluguel(carg);

    }

}