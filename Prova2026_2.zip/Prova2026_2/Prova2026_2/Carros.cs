﻿public class Carros : Veiculo
{
    public int qtdPortas;
    public double bagageiro;

    public override double CalcularAluguel(int dia)
    {

        if (dia > 7)
        {
            return base.CalcularAluguel(dia) * 0.90;
        }
        return base.CalcularAluguel(dia);
        
    }
}