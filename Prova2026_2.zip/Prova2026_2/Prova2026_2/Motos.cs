﻿public class Motos : Veiculo
{
    public double cilindradas;
    public bool partidaEle;
    public double peso;
    public double tanque;

    public override double CalcularAluguel(int dia)
    {

        if (dia > 5)
        {
            return base.CalcularAluguel(dia) * 0.85;
        }
        return base.CalcularAluguel(dia);

    }
}