﻿using System.Collections.Concurrent;
try
{
    Carros c = new Carros();
    c.GetDiaria(100);
    Aluguel a = new Aluguel(c, new DateTime(2008, 08, 01), new DateTime(2008, 08, 11));
    Console.WriteLine(a.CalcularTotalAluguel());


    Caminhoes ca = new Caminhoes();
    ca.GetDiaria(100);
    Console.WriteLine(ca.CalcularAluguel(20000));
    Aluguel a2 = new Aluguel(ca, new DateTime(2008, 08, 01), new DateTime(2008, 08, 11));
    Console.WriteLine("Caminhão "+a2.CalcularTotalAluguel());




    Motos m = new Motos();
    m.GetDiaria(7);
    Console.WriteLine(c.CalcularAluguel(6));
    Aluguel a3 = new Aluguel(m, new DateTime(2008, 08, 12), new DateTime(2009, 08, 12));
    Console.WriteLine(a3.CalcularTotalAluguel());




}
catch(Exception ex)
{
    Console.WriteLine(ex.Message);
}