﻿public abstract class Veiculo
{
    public int id;
    public string descricao;
    public string marca;
    public string ano;
    protected double diaAlug;

    public double GetDiaria(double dia)
    {
       diaAlug = dia;
        return diaAlug;
    }
    public void SetDiaria(double dia)
    {
        if(dia > 0)
        {
            diaAlug = dia;
        }
        throw new Exception("O valor da diaria deve ser maior que 0");
    }

    public virtual double CalcularAluguel(int dia)
    {
        double valor;
        valor = dia * diaAlug;
        return valor;
    }

}