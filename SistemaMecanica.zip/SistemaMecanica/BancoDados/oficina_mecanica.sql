CREATE DATABASE IF NOT EXISTS oficina_mecanica
  
USE oficina_mecanica;

CREATE TABLE IF NOT EXISTS clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS mecanicos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    especialidade VARCHAR(80) NOT NULL
);

CREATE TABLE IF NOT EXISTS veiculos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    tipo ENUM('Carro','Moto') NOT NULL,
    marca VARCHAR(60) NOT NULL,
    modelo VARCHAR(60) NOT NULL,
    placa VARCHAR(10) NOT NULL UNIQUE,
    ano INT NOT NULL,
    portas INT NULL,
    cilindradas INT NULL,
    CONSTRAINT fk_veiculos_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    CONSTRAINT chk_tipo_veiculo CHECK (
      (tipo = 'Carro' AND portas IS NOT NULL AND cilindradas IS NULL) OR
      (tipo = 'Moto' AND cilindradas IS NOT NULL AND portas IS NULL)
    )
);

CREATE TABLE IF NOT EXISTS pecas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    quantidade INT NOT NULL DEFAULT 0,
    preco DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT chk_peca_quantidade CHECK (quantidade >= 0),
    CONSTRAINT chk_peca_preco CHECK (preco >= 0)
);

CREATE TABLE IF NOT EXISTS servicos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(150) NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_servico_valor CHECK (valor >= 0)
);

CREATE TABLE IF NOT EXISTS ordens_servico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    veiculo_id INT NOT NULL,
    mecanico_id INT NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    mao_de_obra DECIMAL(10,2) NOT NULL DEFAULT 0,
    status ENUM('Aberta','Finalizada') NOT NULL DEFAULT 'Aberta',
    data_abertura DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_os_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    CONSTRAINT fk_os_veiculo FOREIGN KEY (veiculo_id) REFERENCES veiculos(id),
    CONSTRAINT fk_os_mecanico FOREIGN KEY (mecanico_id) REFERENCES mecanicos(id),
    CONSTRAINT chk_os_mao CHECK (mao_de_obra >= 0)
);

CREATE TABLE IF NOT EXISTS itens_ordem (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ordem_id INT NOT NULL,
    peca_id INT NOT NULL,
    quantidade INT NOT NULL,
    valor_unitario DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_item_ordem FOREIGN KEY (ordem_id) REFERENCES ordens_servico(id),
    CONSTRAINT fk_item_peca FOREIGN KEY (peca_id) REFERENCES pecas(id),
    CONSTRAINT chk_item_quantidade CHECK (quantidade > 0),
    CONSTRAINT chk_item_valor CHECK (valor_unitario >= 0)
);

CREATE TABLE IF NOT EXISTS movimentacoes_estoque (
    id INT AUTO_INCREMENT PRIMARY KEY,
    peca_id INT NOT NULL,
    tipo ENUM('Entrada','Saida') NOT NULL,
    quantidade INT NOT NULL,
    observacao VARCHAR(255) NULL,
    data_hora DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mov_peca FOREIGN KEY (peca_id) REFERENCES pecas(id),
    CONSTRAINT chk_mov_quantidade CHECK (quantidade > 0)
);
