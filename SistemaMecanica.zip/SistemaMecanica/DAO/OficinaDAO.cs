using MySqlConnector;
using SistemaMecanica.Data;
using SistemaMecanica.Models;

namespace SistemaMecanica.DAO;

public class OficinaDAO
{
    public void CadastrarCliente(Cliente cliente)
    {
        using var conexao = ConexaoBanco.Criar();
        using var cmd = new MySqlCommand(
            "INSERT INTO clientes (nome, telefone, cpf) VALUES (@nome, @telefone, @cpf)", conexao);
        cmd.Parameters.AddWithValue("@nome", cliente.Nome);
        cmd.Parameters.AddWithValue("@telefone", cliente.Telefone);
        cmd.Parameters.AddWithValue("@cpf", cliente.Cpf);
        cmd.ExecuteNonQuery();
    }

    public List<Cliente> ListarClientes()
    {
        var lista = new List<Cliente>();
        using var conexao = ConexaoBanco.Criar();
        using var cmd = new MySqlCommand("SELECT * FROM clientes ORDER BY nome", conexao);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lista.Add(new Cliente {
                Id = reader.GetInt32("id"),
                Nome = reader.GetString("nome"),
                Telefone = reader.GetString("telefone"),
                Cpf = reader.GetString("cpf")
            });
        }
        return lista;
    }

    public void CadastrarVeiculo(Veiculo veiculo)
    {
        using var conexao = ConexaoBanco.Criar();
        using var cmd = new MySqlCommand(
            "INSERT INTO veiculos (cliente_id, tipo, marca, modelo, placa, ano, portas, cilindradas) " +
            "VALUES (@cliente, @tipo, @marca, @modelo, @placa, @ano, @portas, @cilindradas)", conexao);
        cmd.Parameters.AddWithValue("@cliente", veiculo.ClienteId);
        cmd.Parameters.AddWithValue("@tipo", veiculo.TipoVeiculo());
        cmd.Parameters.AddWithValue("@marca", veiculo.Marca);
        cmd.Parameters.AddWithValue("@modelo", veiculo.Modelo);
        cmd.Parameters.AddWithValue("@placa", veiculo.Placa);
        cmd.Parameters.AddWithValue("@ano", veiculo.Ano);
        cmd.Parameters.AddWithValue("@portas", veiculo is Carro carro ? carro.QuantidadePortas : DBNull.Value);
        cmd.Parameters.AddWithValue("@cilindradas", veiculo is Moto moto ? moto.Cilindradas : DBNull.Value);
        cmd.ExecuteNonQuery();
    }

    public List<string> ListarVeiculos()
    {
        var lista = new List<string>();
        using var conexao = ConexaoBanco.Criar();
        string sql = @"SELECT v.id, v.tipo, v.marca, v.modelo, v.placa, v.ano, c.nome AS cliente
                       FROM veiculos v INNER JOIN clientes c ON c.id = v.cliente_id ORDER BY v.id";
        using var cmd = new MySqlCommand(sql, conexao);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
            lista.Add($"{reader.GetInt32("id")} - {reader.GetString("tipo")} {reader.GetString("marca")} " +
                      $"{reader.GetString("modelo")} | Placa: {reader.GetString("placa")} | " +
                      $"{reader.GetString("cliente")}");
        return lista;
    }

    public void CadastrarPeca(Peca peca)
    {
        using var conexao = ConexaoBanco.Criar();
        using var cmd = new MySqlCommand(
            "INSERT INTO pecas (nome, quantidade, preco) VALUES (@nome, @quantidade, @preco)", conexao);
        cmd.Parameters.AddWithValue("@nome", peca.Nome);
        cmd.Parameters.AddWithValue("@quantidade", peca.Quantidade);
        cmd.Parameters.AddWithValue("@preco", peca.Preco);
        cmd.ExecuteNonQuery();
    }

    public List<Peca> ListarPecas()
    {
        var lista = new List<Peca>();
        using var conexao = ConexaoBanco.Criar();
        using var cmd = new MySqlCommand("SELECT * FROM pecas ORDER BY nome", conexao);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
            lista.Add(new Peca {
                Id = reader.GetInt32("id"),
                Nome = reader.GetString("nome"),
                Quantidade = reader.GetInt32("quantidade"),
                Preco = reader.GetDecimal("preco")
            });
        return lista;
    }

    public void MovimentarEstoque(int pecaId, int quantidade, bool entrada)
    {
        if (quantidade <= 0) throw new Exception("A quantidade deve ser maior que zero.");
        using var conexao = ConexaoBanco.Criar();
        using var transacao = conexao.BeginTransaction();
        try
        {
            string operacao = entrada ? "+" : "-";
            string sql = $"UPDATE pecas SET quantidade = quantidade {operacao} @q WHERE id = @id";
            if (!entrada) sql += " AND quantidade >= @q";
            using var cmd = new MySqlCommand(sql, conexao, transacao);
            cmd.Parameters.AddWithValue("@q", quantidade);
            cmd.Parameters.AddWithValue("@id", pecaId);
            if (cmd.ExecuteNonQuery() == 0)
                throw new Exception("Peça não encontrada ou estoque insuficiente.");
            using var hist = new MySqlCommand(
                "INSERT INTO movimentacoes_estoque (peca_id, tipo, quantidade) VALUES (@id, @tipo, @q)",
                conexao, transacao);
            hist.Parameters.AddWithValue("@id", pecaId);
            hist.Parameters.AddWithValue("@tipo", entrada ? "Entrada" : "Saida");
            hist.Parameters.AddWithValue("@q", quantidade);
            hist.ExecuteNonQuery();
            transacao.Commit();
        }
        catch { transacao.Rollback(); throw; }
    }

    public void CadastrarMecanico(Mecanico mecanico)
    {
        using var conexao = ConexaoBanco.Criar();
        using var cmd = new MySqlCommand(
            "INSERT INTO mecanicos (nome, telefone, especialidade) VALUES (@nome, @telefone, @esp)", conexao);
        cmd.Parameters.AddWithValue("@nome", mecanico.Nome);
        cmd.Parameters.AddWithValue("@telefone", mecanico.Telefone);
        cmd.Parameters.AddWithValue("@esp", mecanico.Especialidade);
        cmd.ExecuteNonQuery();
    }

    public void CadastrarServico(Servico servico)
    {
        using var conexao = ConexaoBanco.Criar();
        using var cmd = new MySqlCommand(
            "INSERT INTO servicos (descricao, valor) VALUES (@descricao, @valor)", conexao);
        cmd.Parameters.AddWithValue("@descricao", servico.Descricao);
        cmd.Parameters.AddWithValue("@valor", servico.Valor);
        cmd.ExecuteNonQuery();
    }

    public void AbrirOrdem(OrdemServico ordem)
    {
        using var conexao = ConexaoBanco.Criar();
        using var cmd = new MySqlCommand(
            @"INSERT INTO ordens_servico (cliente_id, veiculo_id, mecanico_id, descricao, mao_de_obra, status)
              VALUES (@cliente, @veiculo, @mecanico, @descricao, @mao, @status)", conexao);
        cmd.Parameters.AddWithValue("@cliente", ordem.ClienteId);
        cmd.Parameters.AddWithValue("@veiculo", ordem.VeiculoId);
        cmd.Parameters.AddWithValue("@mecanico", ordem.MecanicoId);
        cmd.Parameters.AddWithValue("@descricao", ordem.Descricao);
        cmd.Parameters.AddWithValue("@mao", ordem.ValorMaoDeObra);
        cmd.Parameters.AddWithValue("@status", ordem.Status);
        cmd.ExecuteNonQuery();
    }

    public void AdicionarPecaNaOrdem(int ordemId, int pecaId, int quantidade)
    {
        if (quantidade <= 0) throw new Exception("Quantidade inválida.");
        using var conexao = ConexaoBanco.Criar();
        using var transacao = conexao.BeginTransaction();
        try
        {
            using var baixa = new MySqlCommand(
                "UPDATE pecas SET quantidade = quantidade - @q WHERE id = @id AND quantidade >= @q",
                conexao, transacao);
            baixa.Parameters.AddWithValue("@q", quantidade);
            baixa.Parameters.AddWithValue("@id", pecaId);
            if (baixa.ExecuteNonQuery() == 0) throw new Exception("Peça não encontrada ou estoque insuficiente.");

            using var item = new MySqlCommand(
                @"INSERT INTO itens_ordem (ordem_id, peca_id, quantidade, valor_unitario)
                  SELECT @ordem, id, @q, preco FROM pecas WHERE id = @peca",
                conexao, transacao);
            item.Parameters.AddWithValue("@ordem", ordemId);
            item.Parameters.AddWithValue("@q", quantidade);
            item.Parameters.AddWithValue("@peca", pecaId);
            item.ExecuteNonQuery();

            using var hist = new MySqlCommand(
                "INSERT INTO movimentacoes_estoque (peca_id, tipo, quantidade, observacao) VALUES (@id, 'Saida', @q, @obs)",
                conexao, transacao);
            hist.Parameters.AddWithValue("@id", pecaId);
            hist.Parameters.AddWithValue("@q", quantidade);
            hist.Parameters.AddWithValue("@obs", $"Utilizada na ordem {ordemId}");
            hist.ExecuteNonQuery();
            transacao.Commit();
        }
        catch { transacao.Rollback(); throw; }
    }

    public List<string> ListarOrdens()
    {
        var lista = new List<string>();
        using var conexao = ConexaoBanco.Criar();
        string sql = @"SELECT o.id, c.nome AS cliente, v.modelo, v.placa, m.nome AS mecanico,
                       o.descricao, o.mao_de_obra, o.status,
                       COALESCE(SUM(i.quantidade * i.valor_unitario), 0) AS pecas
                       FROM ordens_servico o
                       JOIN clientes c ON c.id=o.cliente_id
                       JOIN veiculos v ON v.id=o.veiculo_id
                       JOIN mecanicos m ON m.id=o.mecanico_id
                       LEFT JOIN itens_ordem i ON i.ordem_id=o.id
                       GROUP BY o.id ORDER BY o.id DESC";
        using var cmd = new MySqlCommand(sql, conexao);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            decimal mao = reader.GetDecimal("mao_de_obra");
            decimal pecas = reader.GetDecimal("pecas");
            lista.Add($"OS {reader.GetInt32("id")} | {reader.GetString("cliente")} | " +
                $"{reader.GetString("modelo")} ({reader.GetString("placa")}) | Mecânico: {reader.GetString("mecanico")} | " +
                $"{reader.GetString("status")} | Total: R$ {mao + pecas:F2} | {reader.GetString("descricao")}");
        }
        return lista;
    }

    public void FinalizarOrdem(int id)
    {
        using var conexao = ConexaoBanco.Criar();
        using var cmd = new MySqlCommand(
            "UPDATE ordens_servico SET status='Finalizada' WHERE id=@id AND status='Aberta'", conexao);
        cmd.Parameters.AddWithValue("@id", id);
        if (cmd.ExecuteNonQuery() == 0) throw new Exception("Ordem não encontrada ou já finalizada.");
    }
}
