using MySqlConnector;

namespace SistemaMecanica.Data;

public static class ConexaoBanco
{
   
    private const string Servidor = "localhost";
    private const string Banco = "oficina_mecanica";
    private const string Usuario = "root";
    private const string Senha = "1541";

    private static readonly string StringConexao =
        $"Server={Servidor};Database={Banco};User ID={Usuario};Password={Senha};";

    public static MySqlConnection Criar()
    {
        var conexao = new MySqlConnection(StringConexao);
        conexao.Open();
        return conexao;
    }
}
