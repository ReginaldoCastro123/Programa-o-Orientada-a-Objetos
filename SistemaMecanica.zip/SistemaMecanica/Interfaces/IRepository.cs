namespace SistemaMecanica.Interfaces;

public interface IRepository<T>
{
    int Inserir(T entidade);
    List<T> ListarTodos();
}
