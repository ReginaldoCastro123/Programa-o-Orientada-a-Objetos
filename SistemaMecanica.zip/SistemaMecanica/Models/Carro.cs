namespace SistemaMecanica.Models;

public class Carro : Veiculo
{
    public int QuantidadePortas { get; set; }
    public override string TipoVeiculo() => "Carro";
}
