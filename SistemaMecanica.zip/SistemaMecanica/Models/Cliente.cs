namespace SistemaMecanica.Models;

public class Cliente : Pessoa
{
    public string Cpf { get; set; } = "";
    public override string MostrarDados()
    {
        return $"Cliente: {Nome} | CPF: {Cpf} | Telefone: {Telefone}";
    }
}
