namespace SistemaMecanica.Models;

public class Mecanico : Pessoa
{
    public string Especialidade { get; set; } = "";
}
