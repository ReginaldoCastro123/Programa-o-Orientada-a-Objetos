namespace SistemaMecanica.Models;

public class Moto : Veiculo
{
    public int Cilindradas { get; set; }
    public override string TipoVeiculo() => "Moto";
}
