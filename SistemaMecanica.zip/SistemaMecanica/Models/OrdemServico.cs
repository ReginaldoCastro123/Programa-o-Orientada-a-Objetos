namespace SistemaMecanica.Models;

public class OrdemServico
{
    public int Id { get; set; }
    public int ClienteId { get; set; }
    public int VeiculoId { get; set; }
    public int MecanicoId { get; set; }
    public string Descricao { get; set; } = "";
    public decimal ValorMaoDeObra { get; set; }
    public string Status { get; set; } = "Aberta";

    public decimal CalcularValorTotal(decimal valorPecas)
    {
        return ValorMaoDeObra + valorPecas;
    }
}
