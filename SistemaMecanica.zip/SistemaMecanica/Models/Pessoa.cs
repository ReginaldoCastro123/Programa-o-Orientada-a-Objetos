namespace SistemaMecanica.Models;

public abstract class Pessoa
{
    public int Id { get; set; }
    public string Nome { get; set; } = "";
    public string Telefone { get; set; } = "";

    public virtual string MostrarDados()
    {
        return $"{Nome} - {Telefone}";
    }
}
