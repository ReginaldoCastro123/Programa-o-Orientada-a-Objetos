namespace SistemaMecanica.Models;

public class Servico
{
    public int Id { get; set; }
    public string Descricao { get; set; } = "";
    public decimal Valor { get; set; }
}
