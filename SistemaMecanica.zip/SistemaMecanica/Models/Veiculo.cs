namespace SistemaMecanica.Models;

public abstract class Veiculo
{
    public int Id { get; set; }
    public int ClienteId { get; set; }
    public string Marca { get; set; } = "";
    public string Modelo { get; set; } = "";
    public string Placa { get; set; } = "";
    public int Ano { get; set; }

    public abstract string TipoVeiculo();
    public virtual string MostrarDados()
    {
        return $"{TipoVeiculo()} - {Marca} {Modelo} ({Ano}) - Placa: {Placa}";
    }
}
