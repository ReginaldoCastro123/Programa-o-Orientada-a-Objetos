using System.Text;
using SistemaMecanica.Data;
using SistemaMecanica.UI;

Console.OutputEncoding = Encoding.UTF8;

try
{
    using var conexao = ConexaoBanco.Criar();
    Console.WriteLine("Conexao com o MySQL realizada com sucesso!");
    new MenuConsole().Executar();
}
catch (Exception ex)
{
    Console.WriteLine("Nao foi possivel conectar ao banco de dados.");
    Console.WriteLine("Confira se o MySQL esta iniciado e se os dados em Data/ConexaoBanco.cs estao corretos.");
    Console.WriteLine($"Detalhe: {ex.Message}");
    Console.WriteLine("\nPressione qualquer tecla para sair...");
    Console.ReadKey();
}
