
# Sistema de Oficina Mecânica

Trabalho de Programação Orientada a Objetos — aplicação de console em C# (.NET 8) com banco de dados MySQL.

O sistema permite cadastrar clientes, veículos (carros e motos), mecânicos, peças e serviços. Também permite controlar a entrada e saída de peças do estoque e registrar ordens de serviço.

## Requisitos

Antes de executar o projeto, instale:

- .NET 8 SDK
- MySQL Server
- MySQL Workbench
- Visual Studio Code (o VS Code roxinho)

O MySQL Server precisa estar instalado e em execução. O Workbench será utilizado para acessar o banco e executar o script SQL.

## 1. Preparar o Visual Studio Code

### 1.1 Instalar a extensão C# Dev Kit

1. Abra o Visual Studio Code (o roxinho).
2. Abra a área de extensões pelo ícone de quadradinhos na barra lateral ou pressione `Ctrl + Shift + X`.
3. Pesquise por `C# Dev Kit`.
4. Escolha a extensão **C# Dev Kit**, publicada pela Microsoft, e clique em Instalar.

Caso a instalação pelo botão abra o Visual Studio azul ou não funcione, faça pelo terminal integrado do VS Code:

1. Abra o VS Code roxinho.
2. Abra o terminal em Terminal > Novo Terminal.
3. Execute:

```powershell
code --install-extension ms-dotnettools.csdevkit
```

4. Para instalar também a extensão C# da Microsoft, execute:

```powershell
code --install-extension ms-dotnettools.csharp
```

5. Aguarde a instalação. Se necessário, feche e abra o VS Code novamente.

**Atenção:** os comandos devem ser executados no terminal do VS Code roxinho. Não é necessário abrir o Visual Studio azul.

### 1.2 Conferir o .NET

No terminal integrado do VS Code, execute:

```bash
dotnet --version
```

O comando deve mostrar a versão instalada do .NET. Para este projeto, é necessário ter o .NET 8 SDK.

Se aparecer que `dotnet` não é reconhecido, instale o .NET 8 SDK e abra novamente o VS Code.

## 2. Criar o banco de dados no MySQL Workbench

1. Abra o MySQL Workbench.
2. Conecte-se ao seu servidor MySQL local.
3. Abra o arquivo `BancoDados/oficina_mecanica.sql` pelo menu File > Open SQL Script.
4. Execute o script clicando no ícone de raio.
5. Atualize a lista de Schemas.
6. Confira se o banco `oficina_mecanica` apareceu.

O script cria o banco e as tabelas necessárias para o funcionamento do sistema.

## 3. Configurar a conexão com o banco

Abra o arquivo:

`Data/ConexaoBanco.cs`

Localize estas configurações:

```csharp
private const string Servidor = "localhost";
private const string Banco = "oficina_mecanica";
private const string Usuario = "root";
private const string Senha = "SUA_SENHA_AQUI";
```

Altere:

- `Usuario`: usuário utilizado no seu MySQL (normalmente root).
- `Senha`: senha definida para esse usuário no MySQL.
- `Servidor`: mantenha localhost se o MySQL estiver instalado no próprio computador.
- `Banco`: mantenha oficina_mecanica, que é o banco criado pelo script.

Salve o arquivo depois de alterar a senha.

## 4. Abrir e executar o projeto no VS Code

1. Extraia o arquivo ZIP do projeto para uma pasta do computador.
2. Abra o VS Code.
3. Clique em Arquivo > Abrir Pasta.
4. Selecione a pasta `SistemaMecanica` (a pasta que contém o arquivo `SistemaMecanica.csproj`).
5. Abra o terminal integrado em Terminal > Novo Terminal.
6. Execute os comandos abaixo, um de cada vez:

```bash
dotnet restore
```

Depois:

```bash
dotnet run
```

O comando `dotnet restore` baixa as dependências do projeto. Na primeira execução, é necessário ter internet para baixar o pacote MySqlConnector.

O comando `dotnet run` compila e inicia o sistema. Se a conexão estiver correta e o MySQL estiver ligado, será exibido o menu da oficina.

## 5. Ordem sugerida para testar

Para testar as funcionalidades, siga esta ordem:

1. Cadastre um cliente.
2. Consulte os clientes e anote o ID gerado.
3. Cadastre um carro ou uma moto informando o ID do cliente.
4. Cadastre um mecânico.
5. Cadastre uma peça com uma quantidade inicial.
6. Cadastre um serviço.
7. Abra uma ordem de serviço informando os IDs do cliente, veículo e mecânico.
8. Vincule uma peça à ordem. O sistema desconta a quantidade utilizada do estoque.
9. Consulte as ordens de serviço.
10. Finalize uma ordem.

Também é possível testar a entrada e a saída de peças diretamente pelo menu de estoque.

## 6. Funcionalidades do menu

- Cadastro e consulta de clientes.
- Cadastro de carros e motos.
- Cadastro de mecânicos.
- Cadastro e consulta de peças.
- Entrada e saída de peças no estoque.
- Cadastro de serviços.
- Abertura de ordens de serviço.
- Inclusão de peças em uma ordem, com baixa automática no estoque.
- Consulta e finalização de ordens de serviço.

## 7. Organização do projeto

```text
SistemaMecanica/
├── BancoDados/
│   └── oficina_mecanica.sql
├── DAO/
│   └── OficinaDAO.cs
├── Data/
│   └── ConexaoBanco.cs
├── Interfaces/
│   └── IRepository.cs
├── Models/
│   ├── Pessoa.cs
│   ├── Cliente.cs
│   ├── Veiculo.cs
│   ├── Carro.cs
│   ├── Moto.cs
│   ├── Mecanico.cs
│   ├── Peca.cs
│   ├── Servico.cs
│   └── OrdemServico.cs
├── UI/
│   └── MenuConsole.cs
├── Program.cs
└── SistemaMecanica.csproj
```

- **Models:** classes e atributos utilizados no sistema. Também contém exemplos de herança e polimorfismo.
- **Interfaces:** contrato genérico inicial para operações de repositório.
- **DAO:** comandos SQL responsáveis pelo acesso e manipulação dos dados.
- **Data:** configuração e abertura da conexão com o MySQL.
- **UI:** menu de interação pelo terminal.
- **BancoDados:** script SQL para criação do banco e das tabelas.
- **Program.cs:** ponto de entrada da aplicação.

## 8. Observação sobre as ordens de serviço

O cadastro de serviços permite registrar os serviços oferecidos pela oficina. Nesta versão, ao abrir uma ordem, a descrição do serviço e o valor da mão de obra são informados diretamente.

As peças utilizadas são vinculadas à ordem e têm suas quantidades descontadas do estoque.

O total exibido na consulta considera a mão de obra e o valor das peças utilizadas.

## 9. Problemas comuns

**Erro de conexão com o MySQL**

- Confira se o MySQL Server está iniciado.
- Confira servidor, usuário e senha em `Data/ConexaoBanco.cs`.
- Confira se o script SQL foi executado e se o banco `oficina_mecanica` existe.

**Comando dotnet não reconhecido**

- Verifique se o .NET 8 SDK foi instalado.
- Feche e abra novamente o VS Code e tente `dotnet --version`.

**Comando code não reconhecido ao instalar extensão**

- Abra o terminal integrado dentro do próprio VS Code roxinho.
- Se ainda não funcionar, instale a extensão pela aba de extensões do VS Code, pesquisando pelo nome e pelo publicador Microsoft.

**Erro ao restaurar o pacote**

- Verifique a conexão com a internet e execute novamente `dotnet restore`.
