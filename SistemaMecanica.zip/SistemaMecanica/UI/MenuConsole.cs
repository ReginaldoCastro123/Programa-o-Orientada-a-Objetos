using SistemaMecanica.DAO;
using SistemaMecanica.Models;

namespace SistemaMecanica.UI;

public class MenuConsole
{
    private readonly OficinaDAO dao = new();

    public void Executar()
    {
        int opcao;
        do
        {
            Console.Clear();
            Console.WriteLine("===== OFICINA MECANICA =====");
            Console.WriteLine("1 - Cadastrar cliente");
            Console.WriteLine("2 - Listar clientes");
            Console.WriteLine("3 - Cadastrar carro ou moto");
            Console.WriteLine("4 - Listar veiculos");
            Console.WriteLine("5 - Cadastrar mecanico");
            Console.WriteLine("6 - Cadastrar peca");
            Console.WriteLine("7 - Listar pecas");
            Console.WriteLine("8 - Entrada de estoque");
            Console.WriteLine("9 - Saida de estoque");
            Console.WriteLine("10 - Cadastrar servico");
            Console.WriteLine("11 - Abrir ordem de servico");
            Console.WriteLine("12 - Utilizar peca em uma ordem");
            Console.WriteLine("13 - Listar ordens de servico");
            Console.WriteLine("14 - Finalizar ordem");
            Console.WriteLine("0 - Sair");
            Console.Write("\nEscolha: ");
            int.TryParse(Console.ReadLine(), out opcao);

            try
            {
                switch (opcao)
                {
                    case 1: CadastrarCliente(); break;
                    case 2: Mostrar(dao.ListarClientes().Select(c => c.MostrarDados())); break;
                    case 3: CadastrarVeiculo(); break;
                    case 4: Mostrar(dao.ListarVeiculos()); break;
                    case 5: CadastrarMecanico(); break;
                    case 6: CadastrarPeca(); break;
                    case 7: Mostrar(dao.ListarPecas().Select(p => $"{p.Id} - {p.Nome} | Qtd: {p.Quantidade} | R$ {p.Preco:F2}")); break;
                    case 8: Movimentar(true); break;
                    case 9: Movimentar(false); break;
                    case 10: CadastrarServico(); break;
                    case 11: AbrirOrdem(); break;
                    case 12: UtilizarPeca(); break;
                    case 13: Mostrar(dao.ListarOrdens()); break;
                    case 14: FinalizarOrdem(); break;
                    case 0: Console.WriteLine("Encerrando..."); break;
                    default: Console.WriteLine("Opcao invalida."); break;
                }
            }
            catch (Exception ex) { Console.WriteLine($"Erro: {ex.Message}"); }
            if (opcao != 0) { Console.WriteLine("\nPressione uma tecla para continuar..."); Console.ReadKey(); }
        } while (opcao != 0);
    }

    private static string Ler(string mensagem)
    {
        Console.Write(mensagem);
        return Console.ReadLine()?.Trim() ?? "";
    }
    private static int LerInt(string mensagem)
    {
        int.TryParse(Ler(mensagem), out int valor);
        return valor;
    }
    private static decimal LerDecimal(string mensagem)
    {
        decimal.TryParse(Ler(mensagem).Replace(',', '.'), System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out decimal valor);
        return valor;
    }
    private static void Mostrar(IEnumerable<string> itens)
    {
        Console.WriteLine();
        foreach (var item in itens) Console.WriteLine(item);
        if (!itens.Any()) Console.WriteLine("Nenhum registro encontrado.");
    }
    private void CadastrarCliente()
    {
        dao.CadastrarCliente(new Cliente { Nome = Ler("Nome: "), Telefone = Ler("Telefone: "), Cpf = Ler("CPF: ") });
        Console.WriteLine("Cliente cadastrado!");
    }
    private void CadastrarVeiculo()
    {
        int cliente = LerInt("ID do cliente: ");
        string tipo = Ler("Tipo (C = Carro / M = Moto): ").ToUpper();
        string marca = Ler("Marca: ");
        string modelo = Ler("Modelo: ");
        string placa = Ler("Placa: ").ToUpper();
        int ano = LerInt("Ano: ");
        Veiculo veiculo;
        if (tipo == "C")
            veiculo = new Carro { ClienteId=cliente, Marca=marca, Modelo=modelo, Placa=placa, Ano=ano,
                QuantidadePortas=LerInt("Quantidade de portas: ") };
        else if (tipo == "M")
            veiculo = new Moto { ClienteId=cliente, Marca=marca, Modelo=modelo, Placa=placa, Ano=ano,
                Cilindradas=LerInt("Cilindradas: ") };
        else throw new Exception("Tipo de veículo inválido.");
        dao.CadastrarVeiculo(veiculo);
        Console.WriteLine("Veiculo cadastrado!");
    }
    private void CadastrarMecanico()
    {
        dao.CadastrarMecanico(new Mecanico { Nome=Ler("Nome: "), Telefone=Ler("Telefone: "),
            Especialidade=Ler("Especialidade: ") });
        Console.WriteLine("Mecanico cadastrado!");
    }
    private void CadastrarPeca()
    {
        dao.CadastrarPeca(new Peca { Nome=Ler("Nome da peca: "), Quantidade=LerInt("Quantidade inicial: "),
            Preco=LerDecimal("Preco unitario: ") });
        Console.WriteLine("Peca cadastrada!");
    }
    private void Movimentar(bool entrada)
    {
        dao.MovimentarEstoque(LerInt("ID da peca: "), LerInt("Quantidade: "), entrada);
        Console.WriteLine("Estoque atualizado!");
    }
    private void CadastrarServico()
    {
        dao.CadastrarServico(new Servico { Descricao=Ler("Descricao do servico: "), Valor=LerDecimal("Valor: ") });
        Console.WriteLine("Servico cadastrado!");
    }
    private void AbrirOrdem()
    {
        dao.AbrirOrdem(new OrdemServico { ClienteId=LerInt("ID do cliente: "), VeiculoId=LerInt("ID do veiculo: "),
            MecanicoId=LerInt("ID do mecanico: "), Descricao=Ler("Descricao do problema/servico: "),
            ValorMaoDeObra=LerDecimal("Valor da mao de obra: ") });
        Console.WriteLine("Ordem de servico aberta!");
    }
    private void UtilizarPeca()
    {
        dao.AdicionarPecaNaOrdem(LerInt("ID da ordem: "), LerInt("ID da peca: "), LerInt("Quantidade: "));
        Console.WriteLine("Peca vinculada a ordem e estoque atualizado!");
    }
    private void FinalizarOrdem()
    {
        dao.FinalizarOrdem(LerInt("ID da ordem: "));
        Console.WriteLine("Ordem finalizada!");
    }
}
